<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>home</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width">
<meta name="_token" content="<?php echo csrf_token(); ?>"/>
<?php echo $__env->yieldContent('meta'); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo asset('bootstrap/css/select2.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('bootstrap/css/bootstrap.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('fuelux/css/fuelux.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('bootstrap/css/datatables-1.10.12.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('bootstrap/css/bootstrap-datepicker3.css'); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/side-menu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/main.css')); ?>">
<?php echo $__env->yieldSection(); ?>
<!-- App -->
<script>
    window.App = window.App || {};
    App.siteURL = '<?php echo e(URL::to("/")); ?>';
    App.currentURL = '<?php echo e(URL::current()); ?>';
    App.fullURL = '<?php echo e(URL::full()); ?>';
    App.apiURL = '<?php echo e(URL::to("api")); ?>';
    App.assetURL = '<?php echo e(URL::to("assets")); ?>';
</script>

<!-- jQuery and Modernizr -->

</head>
    <body>
        <div class="container">
            <div class="content">
                <div class="title">Laravel 5</div>
            </div>
        </div>
    </body>
</html>
