<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ItemService extends Model {

	protected $table = 'item_services';
	public $timestamps = true;

	use SoftDeletes;

	protected $dates = ['deleted_at'];
	protected $fillable = array('name', 'description', 'attachment');

	public function categoryItem()
	{
		return $this->belongsTo('App\CategoryItem', 'category_item_id');
	}

	public function serviceDescriptions()
	{
		return $this->hasMany('App\ServiceDescription');
	}

}