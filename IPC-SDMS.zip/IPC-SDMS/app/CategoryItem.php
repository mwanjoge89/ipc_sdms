<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CategoryItem extends Model {

	protected $table = 'category_items';
	public $timestamps = true;

	use SoftDeletes;

	protected $dates = ['deleted_at'];
	protected $fillable = array('name', 'description', 'attachment');

	public function category()
	{
		return $this->belongsTo('App\Category', 'category_id');
	}

	public function itemService()
	{
		return $this->hasMany('App\ItemService');
	}

}