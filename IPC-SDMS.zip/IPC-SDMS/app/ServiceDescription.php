<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ServiceDescription extends Model {

	protected $table = 'service_descriptions';
	public $timestamps = true;

	use SoftDeletes;

	protected $dates = ['deleted_at'];
	protected $fillable = array('name', 'description', 'attachment');

	public function itemService()
	{
		return $this->belongsTo('App\ItemService', 'item_service_id');
	}

}