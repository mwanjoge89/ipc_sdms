<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>home</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width">
<meta name="_token" content="{!! csrf_token() !!}"/>
@yield('meta')
@section('style')
    <link rel="stylesheet" href="{!! asset('bootstrap/css/select2.css') !!}">
    <link rel="stylesheet" href="{!! asset('bootstrap/css/bootstrap.css') !!}">
    <link rel="stylesheet" href="{!! asset('fuelux/css/fuelux.css') !!}">
    <link rel="stylesheet" href="{!! asset('bootstrap/css/datatables-1.10.12.css') !!}">
    <link rel="stylesheet" href="{!! asset('bootstrap/css/bootstrap-datepicker3.css') !!}">
    <link rel="stylesheet" href="{{ asset('bootstrap/css/font-awesome.min.css') }}">
    <link rel="stylesheet" href="{{ asset('bootstrap/css/side-menu.css') }}">
    <link rel="stylesheet" href="{{ asset('bootstrap/css/main.css') }}">
@show
<!-- App -->
<script>
    window.App = window.App || {};
    App.siteURL = '{{ URL::to("/") }}';
    App.currentURL = '{{ URL::current() }}';
    App.fullURL = '{{ URL::full() }}';
    App.apiURL = '{{ URL::to("api") }}';
    App.assetURL = '{{ URL::to("assets") }}';
</script>

<!-- jQuery and Modernizr -->

</head>
    <body>
        <div class="container">
            <div class="content">
                <div class="title">Laravel 5</div>
            </div>
        </div>
    </body>
</html>
