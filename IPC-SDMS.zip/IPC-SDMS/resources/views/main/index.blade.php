@extends('layouts.main')
@section('title')
    home
@stop
@section('body')
@stop