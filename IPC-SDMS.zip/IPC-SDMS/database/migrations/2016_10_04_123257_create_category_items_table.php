<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateCategoryItemsTable extends Migration {

	public function up()
	{
		Schema::create('category_items', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->softDeletes();
			$table->string('name', 64);
			$table->string('description', 500);
			$table->string('attachment', 500);
		});
	}

	public function down()
	{
		Schema::drop('category_items');
	}
}