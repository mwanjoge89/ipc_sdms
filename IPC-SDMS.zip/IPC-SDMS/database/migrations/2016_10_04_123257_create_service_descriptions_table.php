<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateServiceDescriptionsTable extends Migration {

	public function up()
	{
		Schema::create('service_descriptions', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->softDeletes();
			$table->string('name', 255);
			$table->string('description', 1000);
			$table->string('attachment', 500);
		});
	}

	public function down()
	{
		Schema::drop('service_descriptions');
	}
}